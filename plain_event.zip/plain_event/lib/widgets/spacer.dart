import 'package:flutter/cupertino.dart';

Widget spacer(_height,_width){
  return SizedBox(
    height: _height,
    width: _width,
  );
}