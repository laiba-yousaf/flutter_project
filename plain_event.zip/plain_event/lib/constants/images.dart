
const String logo = "assets/images/Logo.png";


const String ghost = "assets/images/ghost.png";

const String invitiation = "assets/images/invitiation.jpg";
const String unavilable = "assets/images/unavilable.png";


const String dobatedFoods = "assets/images/dobatedFoods.jpg";
const String recivedFoods = "assets/images/recivedFoods.jpg";
const String AllFoods = "assets/images/AllFoods.jpg";
const String PandingFoods = "assets/images/PandingFoods.jpg";




