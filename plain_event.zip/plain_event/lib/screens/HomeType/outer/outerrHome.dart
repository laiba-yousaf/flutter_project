import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class outerHome extends StatefulWidget {
  final Map AdminData;
  final Map UserData;
  const outerHome({super.key, required this.AdminData, required this.UserData});

  @override
  State<outerHome> createState() => _outerHomeState();
}

class _outerHomeState extends State<outerHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
      child: Text("outerHome"),
    ));
  }
}
