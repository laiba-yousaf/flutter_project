import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:plain_event/widgets/spacer.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class dashboard extends StatelessWidget {
   List<salesdata> data = [
    salesdata('saller', 100),
    salesdata('sale_inner', 50),
    salesdata('sale_outer', 50),
  ];

   List<guestdata> data1 = [
    guestdata('saller', 50),
    guestdata('sale_inner', 30),
    guestdata('sale_outer', 20),
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 300,
          width: 400,
          //color: Colors.red,

           child: SfCartesianChart(
            primaryXAxis: CategoryAxis(),
            title: ChartTitle(text: "Team ticket analysis"),
            legend: Legend(isVisible: true),
            tooltipBehavior: TooltipBehavior(enable: true),
            series: <ChartSeries<salesdata,String>>
            [
              LineSeries<salesdata,String>(dataSource:data,
              xValueMapper: (salesdata sale_value,_)=>sale_value.sale_type,
              yValueMapper: (salesdata sale_value,_)=>sale_value.sale_values,
              name:'sale_values',
              dataLabelSettings: DataLabelSettings(isVisible: true),
              
               )
            ],
           ),


        ),
        //spacer(30, 10),
        SizedBox(height: 20,),
        Container(

           height: 300,
          width: 400,
          //color: Colors.red,

           child: SfCartesianChart(
            primaryXAxis: CategoryAxis(),
            title: ChartTitle(text: "Guest ticket analysis"),
            legend: Legend(isVisible: true),
            tooltipBehavior: TooltipBehavior(enable: true),
            series: <ChartSeries<guestdata,String>>
            [
              LineSeries<guestdata,String>(dataSource:data1,
              xValueMapper: (guestdata guest_value,_)=>guest_value.guest_type,
              yValueMapper: (guestdata sale_value,_)=>sale_value.guest_values,
              name:'sale_values',
              dataLabelSettings: DataLabelSettings(isVisible: true),
              
               )
            ],
           ),

        )
      ],
      
    );
  
  }
}

class salesdata {
  final String sale_type;
  final double sale_values;

  salesdata(this.sale_type, this.sale_values);
}

class guestdata{
  final String guest_type;
  final double guest_values;

  guestdata(this.guest_type, this.guest_values);

}