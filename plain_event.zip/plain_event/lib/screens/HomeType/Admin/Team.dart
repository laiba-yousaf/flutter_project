
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:plain_event/constants/images.dart';
import 'package:plain_event/widgets/MyTextField.dart';
import 'package:plain_event/widgets/spacer.dart';

import '../../../widgets/drop_button.dart';

class teamScreen extends StatefulWidget {
  const teamScreen({super.key});

  @override
  State<teamScreen> createState() => _teamScreenState();
}

class _teamScreenState extends State<teamScreen> {
  final TextEditingController usernamecontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          teamCard("https://cdn.pixabay.com/photo/2014/02/27/16/10/flowers-276014__340.jpg","Mudassir","2019-cs-642","Developer"),
          teamCard("https://cdn.pixabay.com/photo/2014/02/27/16/10/flowers-276014__340.jpg","Mudassir","2019-cs-642","Developer"),
        ],
      ),
    );
  }
}

Widget teamCard(img,name,regNo,designation) {
  // widget.data["disable"] != null ? _disable = widget.data["disable"] : null;
    return InkWell(
      onTap: () {
        // _disable
        //     ?
        // snackbar("Sorry This is unavailable at this time"):
        // Navigator.push(
        //     context,
        //     MaterialPageRoute(
        //         builder: (context) => item(
        //               stalldata: widget.data,
        //               UserData: widget.UserData,
        //             )));
      },
      child: Padding(
        padding: const EdgeInsets.only(top: 12.0, left: 20, right: 20),
        child: Card(
          // decoration: BoxDecoration(
          //   borderRadius: BorderRadius.all(
          //     Radius.circular(10),
          //   ),
          //   color: Colors.grey[200],
          // ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Stack(
              children: [
                Row(
                  children: [
                    Container(
                        width: 100.00,
                        height: 90.00,
                        decoration: new BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          image: img==null
                              ?  DecorationImage(
                                  image: AssetImage(unavilable),
                                  fit: BoxFit.fill,
                                ):DecorationImage(
                            image: NetworkImage(img),
                            fit: BoxFit.fill,
                          ),
                        )),
                    SizedBox(
                      width: 20,
                    ),
                    SizedBox(
                      height: 90,
                      width: 170,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text(
                           name,
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            regNo,
                            style: TextStyle(color: Colors.black),
                          ),Text(
                            designation,
                            style: TextStyle(color: Colors.black),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                // spacer(10.0, 0.0),
                // widget.data["UID"] == widget.UserData["UID"]
                //     ? 
                    const Positioned(
                        right: 5,
                        top: 17,
                        child: drop_button(
                            Coll: "Stall",
                            Doc: "widget.UserDat",
                            disable:true))
                    // : Container()
              ],
            ),
          ),
        ),
      ),
    );}
