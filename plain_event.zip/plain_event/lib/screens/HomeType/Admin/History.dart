import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

import '../../../constants/icons.dart';

class historyscreen extends StatefulWidget {
  const historyscreen({super.key});

  @override
  State<historyscreen> createState() => _historyscreenState();
}

class _historyscreenState extends State<historyscreen> {
  final TextEditingController usernamecontroller = TextEditingController();
  final TextEditingController emailcontroller = TextEditingController();
  final TextEditingController phonenocontroller = TextEditingController();
  final TextEditingController addresscontroller = TextEditingController();
  final TextEditingController userpasswordcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              SizedBox(
                  height: 20,
                  width: 20,
                  child: Image.asset(seller, fit: BoxFit.cover)),
              SizedBox(
                width: 220,
                child: TextField(
                  controller: usernamecontroller,
                  decoration: const InputDecoration(
                      border: UnderlineInputBorder(), hintText: "Total sale ticket"),
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              SizedBox(
                  height: 20,
                  width: 20,
                  child: Image.asset(ticket, fit: BoxFit.cover)),
              SizedBox(
                width: 220,
                child: TextField(
                  controller: emailcontroller,
                  decoration: InputDecoration(
                    border: const UnderlineInputBorder(),
                    hintText: "Total inner seller",
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              SizedBox(
                  height: 20,
                  width: 20,
                  child: Image.asset(ticket, fit: BoxFit.cover)),
              SizedBox(
                width: 220,
                child: TextField(
                  controller: addresscontroller,
                  decoration: InputDecoration(
                    border: const UnderlineInputBorder(),
                    hintText: "Total outer seller",
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );

    // const SizedBox(height: 15),

    // Row(
    //   mainAxisAlignment: MainAxisAlignment.spaceAround,
    //   children: [
    //     SizedBox(
    //         height: 20,
    //         width: 20,
    //         child: Image.asset(lockIcon, fit: BoxFit.cover)),
    //     SizedBox(
    //       width: 220,
    //       child: TextField(
    //         controller: addresscontroller,
    //         decoration: InputDecoration(
    //           border: const UnderlineInputBorder(),
    //           hintText: "Address",
    //         ),
    //       ),
    //     ),
    //   ],
    // ),

    // const SizedBox(height: 15),
    // Row(
    //   mainAxisAlignment: MainAxisAlignment.spaceAround,
    //   children: [
    //     SizedBox(
    //         height: 20,
    //         width: 20,
    //         child: Image.asset(phoneIcon, fit: BoxFit.cover)),
    //     SizedBox(
    //       width: 220,
    //       child: TextField(
    //         controller: phonenocontroller,
    //         decoration: InputDecoration(
    //           border: const UnderlineInputBorder(),
    //           hintText: "Phone Number",
    //         ),
    //       ),
    //     ),
    //   ],
    // ),
    // const SizedBox(height: 15),
    // Row(
    //   mainAxisAlignment: MainAxisAlignment.spaceAround,
    //   children: [
    //     SizedBox(
    //         height: 20,
    //         width: 20,
    //         child: Image.asset(lockIcon, fit: BoxFit.cover)),
    //     SizedBox(
    //       width: 220,
    //       child: TextField(
    //         controller: userpasswordcontroller,
    //         decoration: InputDecoration(
    //           border: const UnderlineInputBorder(),
    //           hintText: "Password",
    //         ),
    //       ),
    //     ),
    //   ],
    // ),
    // // const SizedBox(height: 15),
  }
}
