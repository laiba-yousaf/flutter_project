import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:plain_event/screens/HomeType/Admin/History.dart';
import 'package:plain_event/screens/HomeType/Admin/Team.dart';
import 'package:plain_event/screens/HomeType/Admin/dashboard.dart';
import 'package:plain_event/widgets/spacer.dart';

import '../../../widgets/app_bar/my_app_bar_2.dart';
import '../../Navigation/MyDrawer.dart';

class adminHome extends StatefulWidget {
  final Map AdminData;
  final Map UserData;
  const adminHome({super.key, required this.AdminData, required this.UserData});

  @override
  State<adminHome> createState() => _adminHomeState();
}

class _adminHomeState extends State<adminHome> {
  int _currentIndex = 0;
  final tabs = [
      
      dashboard(),
     teamScreen(),
    historyscreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MyDrawer(
        UserData: widget.UserData,
        AdminData: widget.AdminData,
      ),
      appBar: MyAppBar2(context, "Home", false, () {}, false),
      body: tabs[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.dashboard),
              label: 'Dashboard',
              backgroundColor: Colors.yellow),
          BottomNavigationBarItem(
              icon: Icon(Icons.group),
              label: 'Team',
              backgroundColor: Colors.yellow),
          BottomNavigationBarItem(
              icon: Icon(Icons.history),
              label: 'History',
              backgroundColor: Colors.yellow),
        ],
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          
          });
        },
      ),
    );
  }
}
