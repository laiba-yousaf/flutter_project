import 'package:flutter/cupertino.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class sellerscreen extends StatefulWidget {
  const sellerscreen({super.key});

  @override
  State<sellerscreen> createState() => _sellerscreenState();
}

class _sellerscreenState extends State<sellerscreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('seller screen'),
    );
  }
}