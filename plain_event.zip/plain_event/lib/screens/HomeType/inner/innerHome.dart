import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

import '../../../widgets/app_bar/my_app_bar_2.dart';
import '../../Navigation/MyDrawer.dart';

class innerHome extends StatefulWidget {
  final Map AdminData;
  final Map UserData;
  const innerHome({super.key, required this.AdminData, required this.UserData});

  @override
  State<innerHome> createState() => _innerHomeState();
}

class _innerHomeState extends State<innerHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: MyDrawer(
          UserData: widget.UserData,
          AdminData: widget.AdminData,
        ),
        appBar: MyAppBar2(context, "Home", false, () {}, false),
        body: Center(
          child: Text("innerHome"),
        ));
  }
}
