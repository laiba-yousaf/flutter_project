package com.example.plain_event

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
